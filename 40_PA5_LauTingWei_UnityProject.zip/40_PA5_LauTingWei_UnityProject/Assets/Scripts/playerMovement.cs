﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class playerMovement : MonoBehaviour
{
    public float speed;
    Rigidbody playerRigidBody;
    public Text coincollect;
    public float score;

    // Start is called before the first frame update
    void Start()
    {
        playerRigidBody = GetComponent<Rigidbody>();
       
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        playerRigidBody.AddForce(movement * speed * Time.deltaTime);
        coincollect.text = "Coins collected : " + score;

        if (score >= 8)
        {
            SceneManager.LoadScene("GameWin");
        }
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "coin")
        {
            Destroy(other.gameObject);
            score += 1;
            
            if (score == 4)
            {
                SceneManager.LoadScene("GamePlay_Level2");
            }

        }

        if (other.gameObject.tag == "obstacle")
        {
            SceneManager.LoadScene("GameLose");
        }
    }


}
